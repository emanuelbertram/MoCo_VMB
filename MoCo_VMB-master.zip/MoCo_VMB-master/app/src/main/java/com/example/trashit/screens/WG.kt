package com.example.trashit.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@Composable
fun WG_Create_Screen() {
    //val navController = rememberNavController()

    //    Text(text = "Textzeilen mit WG-Name, Mitglieder, etc", Modifier.fillMaxHeight())



}

@Composable
@Preview
fun WG_Create_ScreenPreview() {
    WG_Create_Screen()
}